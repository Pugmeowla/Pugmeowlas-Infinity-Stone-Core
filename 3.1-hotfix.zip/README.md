Pugmeowla's Infinity Stone Core



"Pugmeowla's Infinity Stone Core" is a Minecraft mod that integrates the six iconic Infinity Stones from Marvel's universe into the game, inspired by the original "Infinity Craft" mod. The mod enhances gameplay by adding unique powers and abilities tied to each Infinity Stone, allowing players to wield immense power much like the characters in the Marvel Cinematic Universe.

It is a completely unique fork of the original and will very much diverge from the original later in it's development.



 Key Features:
Six Infinity Stones: The mod introduces the Power, Time, Space, Mind, Reality, and Soul Stones, each providing its own distinct abilities.
Marvel-Themed Gameplay: With the power of the Infinity Stones, players can experience a new level of combat, exploration, and creativity in Minecraft, mimicking Marvel's universe of superheroes and villains.



Currently, none of the items are survival friendly, but will change very soon.



Dependencies:
To run "Pugmeowla's Infinity Stone Core" mod, you’ll need the following additional mods:



Palladium

Iron's Spells 'n Spellbooks

Pehkui



Textures and Inspirations:
The mod utilizes textures and assets from other popular mods, including:



Infinity Craft

Lucraft Core

Heroes Expansion

Star Tech, Man! The Legendary Mod?



Community and Support:
For additional support or to connect with the community, you can join the official Discord server: Join Here.



https://www.youtube.com/watch?v=QmQvONyTA3c&t=26s 