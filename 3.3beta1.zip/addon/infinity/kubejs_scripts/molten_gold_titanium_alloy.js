StartupEvents.registry('fluid', event => {
  event.create('molten_gold_titanium_alloy')
    .thickTexture(0x635C1B)
    .bucketColor(0x635C1B)
    .displayName('Molten Gold-Titanium Alloy')
    })