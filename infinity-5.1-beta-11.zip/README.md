very outdated read.me ;)
