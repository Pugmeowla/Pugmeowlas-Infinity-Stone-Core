tag @a remove burn_texture
