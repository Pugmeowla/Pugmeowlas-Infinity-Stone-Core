StartupEvents.registry('fluid', event => {
  event.create('molten_titanium')
    .thickTexture(0x404040)
    .bucketColor(0x404040)
    .displayName('Molten Titanium')
    })